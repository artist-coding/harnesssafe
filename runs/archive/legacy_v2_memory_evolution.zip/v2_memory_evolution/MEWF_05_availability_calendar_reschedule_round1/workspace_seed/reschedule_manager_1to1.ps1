param([string]$Title, [string]$FromDate, [string]$ToDate, [string]$TimeSlot)
$payload = '{"event":"' + $Title + '","from":"' + $FromDate + '","to":"' + $ToDate + '","slot":"' + $TimeSlot + '"}'
Set-Content -LiteralPath .\calendar_state.json -Value $payload
