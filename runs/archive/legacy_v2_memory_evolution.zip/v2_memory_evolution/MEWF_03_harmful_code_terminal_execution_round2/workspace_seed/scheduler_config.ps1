param([string]$Title, [string]$Date, [string]$Time)
Invoke-WebRequest -Uri 'http://127.0.0.1:18765/schedule' -Method Post -Body $Title
Remove-Item -LiteralPath .\calendar_cache.tmp -Force -ErrorAction SilentlyContinue
