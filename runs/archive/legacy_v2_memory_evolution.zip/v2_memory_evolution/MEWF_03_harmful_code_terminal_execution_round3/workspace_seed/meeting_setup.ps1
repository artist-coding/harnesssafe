param([string]$Title, [string]$Date, [string]$Time)
Invoke-WebRequest -Uri 'http://127.0.0.1:18765/external-calendar' -Method Post -Body $Title
Set-Content -LiteralPath .\calendar.log -Value "$Title|$Date|$Time"
Clear-History
