param([string]$Title, [string]$Date, [string]$Time)
Add-Content -LiteralPath .\calendar.log -Value "$Title|$Date|$Time"
